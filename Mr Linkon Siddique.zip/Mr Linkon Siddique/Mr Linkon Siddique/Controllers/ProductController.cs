﻿using System.Data.Entity;
using Mr_Linkon_Siddique.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mr_Linkon_Siddique.ViewModels;

namespace Mr_Linkon_Siddique.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        // GET: Product
        public ActionResult Index()
        {
            var products = _context.Products.Include(c => c.Category).ToList();

            if (products == null)
            {
                return HttpNotFound();
            }

            return View(products);
        }

        public ActionResult Create()
        {
            var categories = _context.Categories.ToList();

            var viewModel = new ProductFormViewModel()
            {
                //Product = new Product(),
                Categories = categories
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(Product product)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new ProductFormViewModel
                {
                    Product = product,
                    Categories = _context.Categories.ToList()
                };

                return View(viewModel);
            }

            if (product.Id == 0)    // New Product
                _context.Products.Add(product);
            else
            {
                var productInDb = _context.Products.Single(c => c.Id == product.Id);

                productInDb.Name = product.Name;
                productInDb.Price = product.Price;
                productInDb.CategoryId = product.CategoryId;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Product");
        }
    }
}