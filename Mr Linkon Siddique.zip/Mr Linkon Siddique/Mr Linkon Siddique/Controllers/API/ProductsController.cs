﻿using Mr_Linkon_Siddique.Models;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Mr_Linkon_Siddique.Controllers.API
{
    public class ProductsController : ApiController
    {
        private readonly ApplicationDbContext _context;

        public ProductsController()
        {
            _context = new ApplicationDbContext();
        }

        //Get API/Products/id (Category Id)
        public IEnumerable<Product> GetProducts(int id)
        {
            //return _context.Products.ToList();
            return _context.Products.Include(c => c.Category).Where(c => c.CategoryId == id).ToList();
        }
    }
}
